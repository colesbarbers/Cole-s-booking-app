
import Head from 'next/head';
import Link from 'next/link';
import styles from '../styles.module.css';

export default function Home() {
  return (
    <div className={styles.container}>
      <Head>
        <title>Cole&apos;s Booking App</title>
        <meta name="description" content="Book your next haircut with ease at Cole&apos;s Barbers" />
        <link rel="icon" href="/favicon.ico" />
      </Head>

      <main className={styles.main}>
        <h1 className={styles.title}>Welcome to Cole&apos;s Booking App</h1>
        <p className={styles.description}>Book your haircut online with ease</p>
        <Link href="/contact" className={styles.button}>Contact Us</Link>
      </main>

      <footer className={styles.footer}>
        <p>&copy; {new Date().getFullYear()} Cole&apos;s Barbers. All rights reserved.</p>
      </footer>
    </div>
  );
}
